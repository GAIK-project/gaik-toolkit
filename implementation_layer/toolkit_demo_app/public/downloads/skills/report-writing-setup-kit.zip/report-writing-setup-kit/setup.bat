@echo off
setlocal enabledelayedexpansion

:: ============================================================================
:: Report Writing Skill - Setup Script
:: ============================================================================
:: This script helps you set up the Report Writing skill and MCP server
:: ============================================================================

title Report Writing Skill - Setup

echo.
echo ============================================================================
echo            REPORT WRITING SKILL - SETUP WIZARD
echo ============================================================================
echo.
echo This script will help you set up the Report Writing skill.
echo.
echo PREREQUISITES (install these first if you haven't):
echo   1. Claude Desktop - https://claude.ai/download
echo   2. Node.js - https://nodejs.org/
echo   3. OpenAI API key OR Azure OpenAI credentials
echo.
echo ============================================================================
echo.

pause

:: ============================================================================
:: Step 1: Check Python
:: ============================================================================
echo.
echo [Step 1/6] Checking Python installation...
echo ----------------------------------------------------------------------------

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not in PATH.
    echo.
    echo Please install Python 3.11+ from https://www.python.org/downloads/
    echo Make sure to check "Add Python to PATH" during installation.
    echo.
    pause
    exit /b 1
)

for /f "tokens=2" %%i in ('python --version 2^>^&1') do set PYTHON_VERSION=%%i
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)" >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python %PYTHON_VERSION% is too old: gaik needs Python 3.11 or later.
    echo Please install Python 3.11+ from https://www.python.org/downloads/
    echo.
    pause
    exit /b 1
)
echo [OK] Python %PYTHON_VERSION% found.

:: ============================================================================
:: Step 2: Check Node.js
:: ============================================================================
echo.
echo [Step 2/6] Checking Node.js installation...
echo ----------------------------------------------------------------------------

node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [WARNING] Node.js is not installed or not in PATH.
    echo.
    echo Node.js is required for the filesystem MCP server.
    echo Please install from https://nodejs.org/
    echo.
    echo You can continue, but filesystem access won't work until Node.js is installed.
    echo.
    pause
) else (
    for /f "tokens=1" %%i in ('node --version 2^>^&1') do set NODE_VERSION=%%i
    echo [OK] Node.js !NODE_VERSION! found.
)

:: ============================================================================
:: Step 3: Install Python dependencies
:: ============================================================================
echo.
echo [Step 3/6] Installing Python dependencies...
echo ----------------------------------------------------------------------------
echo Installing: mcp==1.30.0, gaik[transcriber]==0.10.0, python-dotenv==1.2.4
echo This may take a few minutes...
echo.

pip install mcp==1.30.0 "gaik[transcriber]==0.10.0" python-dotenv==1.2.4 --quiet

if %errorlevel% neq 0 (
    echo [ERROR] Failed to install dependencies.
    echo Please try running: pip install mcp==1.30.0 "gaik[transcriber]==0.10.0" python-dotenv==1.2.4
    pause
    exit /b 1
)

echo [OK] Dependencies installed successfully.

:: ============================================================================
:: Step 4: Configure API Key
:: ============================================================================
echo.
echo [Step 4/6] Configuring API credentials...
echo ----------------------------------------------------------------------------
echo.
echo Which API provider do you want to use for audio transcription?
echo.
echo   1. OpenAI (recommended)
echo   2. Azure OpenAI
echo   3. Skip (I don't need audio transcription)
echo.

set /p API_CHOICE="Enter your choice (1, 2, or 3): "

set "TRANSCRIPTION_MCP_PATH=%~dp0transcription-MCP"

if "%API_CHOICE%"=="1" (
    echo.
    echo You selected OpenAI.
    echo.
    echo Get your API key from: https://platform.openai.com/api-keys
    echo.
    set /p OPENAI_KEY="Enter your OpenAI API key: "

    if "!OPENAI_KEY!"=="" (
        echo [WARNING] No API key provided. You can add it later to:
        echo %TRANSCRIPTION_MCP_PATH%\.env
    ) else (
        echo.
        echo Creating .env file...
        (
            echo # OpenAI Configuration
            echo OPENAI_API_KEY=!OPENAI_KEY!
            echo OPENAI_API_TYPE=openai
        ) > "%TRANSCRIPTION_MCP_PATH%\.env"
        echo [OK] .env file created at %TRANSCRIPTION_MCP_PATH%\.env
    )
    set API_TYPE=openai

) else if "%API_CHOICE%"=="2" (
    echo.
    echo You selected Azure OpenAI.
    echo.
    echo You'll need your Azure OpenAI credentials.
    echo.
    set /p AZURE_KEY="Enter your Azure API key: "
    set /p AZURE_ENDPOINT="Enter your Azure endpoint URL: "
    set /p AZURE_DEPLOYMENT="Enter your transcription deployment name, for example whisper or gpt-4o-transcribe: "

    if "!AZURE_KEY!"=="" (
        echo [WARNING] No API key provided. You can add it later to:
        echo %TRANSCRIPTION_MCP_PATH%\.env
    ) else (
        echo.
        echo Creating .env file...
        (
            echo # Azure OpenAI Configuration
            echo AZURE_API_KEY=!AZURE_KEY!
            echo AZURE_ENDPOINT=!AZURE_ENDPOINT!
            echo AZURE_TRANSCRIPTION_MODEL=!AZURE_DEPLOYMENT!
            echo OPENAI_API_TYPE=azure
        ) > "%TRANSCRIPTION_MCP_PATH%\.env"
        echo [OK] .env file created at %TRANSCRIPTION_MCP_PATH%\.env
    )
    set API_TYPE=azure

) else (
    echo.
    echo Skipping API configuration.
    echo You can process documents without audio transcription.
    set API_TYPE=none
)

:: ============================================================================
:: Step 5: Check FFmpeg (optional)
:: ============================================================================
echo.
echo [Step 5/6] Checking FFmpeg (optional, for large audio files)...
echo ----------------------------------------------------------------------------

ffmpeg -version >nul 2>&1
if %errorlevel% neq 0 (
    echo [INFO] FFmpeg not found.
    echo.
    echo FFmpeg is optional but needed for audio files larger than 25 MB or longer than 20 minutes.
    echo Download from: https://ffmpeg.org/download.html
    echo.
) else (
    echo [OK] FFmpeg found.
)

:: ============================================================================
:: Step 6: Generate Claude Desktop Configuration
:: ============================================================================
echo.
echo [Step 6/6] Generating Claude Desktop configuration...
echo ----------------------------------------------------------------------------
echo.

:: Get the script directory and normalize the path for JSON
set "SCRIPT_DIR=%~dp0"
set "SERVER_PATH=%SCRIPT_DIR%transcription-MCP\server.py"

:: Convert backslashes to double backslashes for JSON
set "SERVER_PATH_JSON=%SERVER_PATH:\=\\%"

:: Remove trailing backslash if present
if "%SERVER_PATH_JSON:~-2%"=="\\" set "SERVER_PATH_JSON=%SERVER_PATH_JSON:~0,-2%"

:: Create the config file content
set "CONFIG_FILE=%SCRIPT_DIR%claude_desktop_config.json"

(
echo {
echo   "mcpServers": {
echo     "gaik-transcriber": {
echo       "command": "python",
echo       "args": ["%SERVER_PATH_JSON%"],
echo       "timeout": 600000
echo     },
echo     "filesystem": {
echo       "command": "npx",
echo       "args": [
echo         "-y",
echo         "@modelcontextprotocol/server-filesystem@2026.8.31",
echo         "C:\\"
echo       ]
echo     }
echo   }
echo }
) > "%CONFIG_FILE%"

echo [OK] Configuration file generated.

:: ============================================================================
:: Step 7: Create Skill ZIP file
:: ============================================================================
echo.
echo [Bonus] Creating skill ZIP file...
echo ----------------------------------------------------------------------------

:: Check if PowerShell can create zip
powershell -Command "Compress-Archive -Path '%SCRIPT_DIR%SKILL.md','%SCRIPT_DIR%EVALUATION.md','%SCRIPT_DIR%reference' -DestinationPath '%SCRIPT_DIR%report-writing.zip' -Force" >nul 2>&1

if %errorlevel% equ 0 (
    echo [OK] Created report-writing.zip
) else (
    echo [INFO] Could not create ZIP automatically.
    echo       Please manually zip SKILL.md, EVALUATION.md and the 'reference' folder.
)

:: ============================================================================
:: FINAL INSTRUCTIONS
:: ============================================================================
echo.
echo ============================================================================
echo                         SETUP COMPLETE!
echo ============================================================================
echo.
echo NEXT STEPS - Please follow these instructions carefully:
echo.
echo ----------------------------------------------------------------------------
echo STEP A: Copy the MCP configuration to Claude Desktop
echo ----------------------------------------------------------------------------
echo.
echo    1. Open this file in Notepad:
echo       %APPDATA%\Claude\claude_desktop_config.json
echo.
echo    2. If it is missing or empty, paste the ENTIRE content of:
echo       %CONFIG_FILE%
echo.
echo    3. Otherwise add only the gaik-transcriber entry to its mcpServers section
echo       and keep everything else. Then SAVE.
echo.
echo    TIP: Press Win+R, paste the path above, and press Enter to open it.
echo.
echo ----------------------------------------------------------------------------
echo STEP B: Restart Claude Desktop
echo ----------------------------------------------------------------------------
echo.
echo    1. Close Claude Desktop completely (check system tray!)
echo    2. Open Task Manager and end any "Claude" processes
echo    3. Start Claude Desktop again
echo.
echo ----------------------------------------------------------------------------
echo STEP C: Install the Skill in Claude Desktop
echo ----------------------------------------------------------------------------
echo.
echo    1. Open Claude Desktop
echo    2. Go to Customize then Skills
echo    3. Click Add then Upload skill
echo    4. Upload: %SCRIPT_DIR%report-writing.zip
echo.
echo ----------------------------------------------------------------------------
echo STEP D: Test the Setup
echo ----------------------------------------------------------------------------
echo.
echo    In Claude Desktop, try:
echo    "Create a report from the materials in C:\path\to\your\folder"
echo.
echo ============================================================================
echo.
echo Configuration file saved to:
echo    %CONFIG_FILE%
echo.
echo Open it now to copy the content? (Y/N)
set /p OPEN_CONFIG="Your choice: "

if /i "%OPEN_CONFIG%"=="Y" (
    notepad "%CONFIG_FILE%"
)

echo.
echo Also open the Claude Desktop config location? (Y/N)
set /p OPEN_CLAUDE="Your choice: "

if /i "%OPEN_CLAUDE%"=="Y" (
    :: Try to open the Claude config directory
    if exist "%APPDATA%\Claude\" (
        explorer "%APPDATA%\Claude\"
    ) else (
        echo.
        echo Claude config folder not found at %APPDATA%\Claude\
        echo Please create it manually or install Claude Desktop first.
    )
)

echo.
echo ============================================================================
echo Setup script finished. Thank you for using Report Writing Skill!
echo ============================================================================
echo.

pause
