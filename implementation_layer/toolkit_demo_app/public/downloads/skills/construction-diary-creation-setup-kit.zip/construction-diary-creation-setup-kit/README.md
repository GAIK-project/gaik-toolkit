# Construction Diary Creation Skill for Claude Desktop

Transform construction site audio recordings into structured Työmaapäiväkirja (daily diary) documents — automatically.

---

## What Does This Skill Do?

This skill extracts structured information from Finnish construction site manager's audio recordings and creates official daily diary documentation. Simply provide an audio file, and Claude will:

- **Transcribe** the audio recording with OpenAI or Azure OpenAI (`gpt-4o-transcribe` by default)
- **Extract** 20 standardized fields for Työmaapäiväkirja
- **Generate** a formatted Word document with a professional 2-column table
- **Validate** data against predefined work phase lists

### Extracted Fields

The skill extracts essential construction diary information including:
- Site details (Kohde, Laatija, Päivämäärä)
- Weather conditions (Sää)
- Personnel resources (Resurssit - Henkilöstö)
- Daily work tasks (Päivän työt)
- Work phases: started, ongoing, completed, interrupted (from predefined lists)
- Events, deviations, inspections, and supervisor notes

### Supported Audio Formats

`.mp3`, `.m4a`, `.wav`, `.ogg`, `.flac`, `.mp4`, `.webm` (convert `.mov`, `.avi` or `.mkv` to one of these first)

---

## Prerequisites

Before setting up, please install:

1. **Claude Desktop** — Download from [claude.ai/download](https://claude.ai/download)
2. **Python 3.11+** — Download from [python.org](https://www.python.org/downloads/)
   - During installation, check **"Add Python to PATH"**
3. **OpenAI API key or Azure OpenAI credentials** (required for transcription) — an OpenAI key comes from [platform.openai.com/api-keys](https://platform.openai.com/api-keys)

---

## Setup

### Quick Setup (5 Minutes)

**Step 1: Run the Setup Script**

1. Double-click `setup.bat` in this folder
2. Follow the prompts:
   - Choose your API provider (OpenAI or Azure OpenAI)
   - Enter your API key (it is saved as your user environment variable, not in a file)
   - Choose the folder Claude may work on, and keep your recordings there

**Step 2: Configure Claude Desktop**

1. The script creates `claude_desktop_config.json` — open it when prompted
2. Press `Win + R`, paste: `%APPDATA%\Claude\claude_desktop_config.json`, press Enter
3. If that file is missing or empty, paste the whole generated content. Otherwise add only the `"gaik-transcriber": {...}` entry to its existing `"mcpServers"` object, keep everything else, and save.

**Step 3: Restart Claude Desktop**

1. Close Claude Desktop completely (check system tray)
2. Open Task Manager and end any "Claude" processes
3. Start Claude Desktop again

**Step 4: Install the Skill**

1. Open Claude Desktop
2. Open **Plugins** in the sidebar (formerly **Customize** → **Skills**) and choose **Upload a skill**
3. Upload `construction-diary-creation.zip` (created by setup script)

✅ **Setup complete!**

---

## How to Use

Simply provide the audio file path to Claude:

```
Process construction diary from C:\path\to\your\audio-file.mp3 using construction-diary-creation skill.
```

### What Happens Next

1. Claude transcribes the audio
2. Extracts 20 fields from the transcript
3. Creates a Word document with a 2-column table
4. Saves it as `Tyomaapaivakirja_[Date].docx`
5. Presents the file for download

---

## Example Output

The generated Word document contains:

```
TYÖMAAPÄIVÄKIRJA
================

| Kenttä                      | Arvo                           |
|-----------------------------|--------------------------------|
| Kohde                       | 3285-00 Komeetankuja 6, Espoo  |
| Laatija                     | Matti Virtanen                 |
| Sää                         | 3 °C, 2 m/s, 78 % suht. kosteus|
| Päivämäärä                  | 20.05.2024                     |
| Resurssit - Henkilöstö      | Työnjohtajat: 2 hlö, ...       |
| Työviikko                   | 21                             |
| Päivän työt                 | sisäpurku, rungon purku        |
| ...                         | ...                            |
```

**Key Features:**
- Fields not mentioned in audio are left empty (no guessing)
- Work phases are validated against predefined lists
- Brief, factual extraction with tight keywords
- Professional formatting suitable for official documentation

---

## Sample Data

Sample recordings are kept in the repository, outside the plugin, so that installing
the plugin does not download audio. Download them from
[`no-code-assets/samples/construction-diary-creation`](https://github.com/GAIK-project/gaik-toolkit/tree/main/implementation_layer/no-code-assets/samples/construction-diary-creation):

| File | Description |
|------|-------------|
| `fin-example-1.mp3` | Finnish construction diary recording |
| `en-example-1.mp3` | English example (for testing) |

**Try it:**
```
Process construction diary from [path-to-download-folder]\fin-example-1.mp3
```

---

## Troubleshooting

### "MCP server not found" error
- Ensure Claude Desktop is fully closed (check system tray)
- Verify the path in `claude_desktop_config.json` is correct
- Restart Claude Desktop

### Audio transcription not working
- Check that the key is saved without showing it: in a new Command Prompt run
  `powershell -c "[bool][Environment]::GetEnvironmentVariable('OPENAI_API_KEY','User')"`
  (or `AZURE_API_KEY`); `False` means it is missing, so run `setup.bat` again
- The transcriber only takes audio and video files inside the folder you chose in setup
  (`--folder` in `claude_desktop_config.json`); move the recording there
- The key is a user environment variable, so other programs you run can read it too; use a
  key made for this skill, and remove it when you stop using it:
  `reg delete HKCU\Environment /v OPENAI_API_KEY /f`
- Verify you have OpenAI credits available
- Test with a smaller audio file first

### Empty or incorrect fields
- The skill only extracts explicitly mentioned information
- If fields are empty, the information wasn't in the audio
- Work phase fields only accept predefined values (see SKILL.md)

---

## Manual Setup (Alternative)

If you prefer manual configuration:

**Install Dependencies:**
```bash
python -m venv transcription-MCP\.venv
transcription-MCP\.venv\Scripts\python.exe -m pip install mcp==1.30.0 "gaik[transcriber]==0.12.0" python-dotenv==1.2.4
```

**Configure API Key:**

Save the key as a user environment variable, not in a file. Open Command Prompt and run
(for **OpenAI**):
```
setx OPENAI_API_KEY "your_api_key_here"
```
For **Azure OpenAI**, save `AZURE_API_KEY` the same way and put the endpoint and deployment
in the server's `env` settings below. On Windows the transcriber reads a key that is missing
from its own environment from your user environment variables, so the key need not be in
`claude_desktop_config.json`.

**Configure Claude Desktop:**

Edit `%APPDATA%\Claude\claude_desktop_config.json`:
```json
{
  "mcpServers": {
    "gaik-transcriber": {
      "command": "C:\\path\\to\\construction-diary-creation\\transcription-MCP\\.venv\\Scripts\\python.exe",
      "args": ["C:\\path\\to\\construction-diary-creation\\transcription-MCP\\server.py",
               "--folder", "C:\\Users\\you\\Documents\\GAIK"],
      "env": {"OPENAI_API_TYPE": "openai"},
      "timeout": 600000
    }
  }
}
```

Replace `C:\\path\\to\\` with where you saved this folder, and `C:\\Users\\you\\Documents\\GAIK` with the folder that holds your recordings.

For Azure OpenAI, `env` holds `"OPENAI_API_TYPE": "azure"`, `AZURE_ENDPOINT` and `AZURE_TRANSCRIPTION_MODEL` instead.
The folder must not be a whole drive, your whole user folder or a folder that holds this one.

**Install Skill:**
1. Zip `SKILL.md`
2. Upload it in Claude Desktop: **Plugins** → **Upload a skill** (formerly **Customize** → **Skills**)

---

## Technical Details

### Project Structure

```
construction-diary-creation/
├── setup.bat                      # Automated setup wizard
├── SKILL.md                       # Skill definition: extraction workflow & field specifications
├── transcription-MCP/             # Audio transcription MCP server
│   ├── server.py                  # FastMCP server implementation
│   └── .venv/                     # the transcriber's own Python (created by setup.bat)
```

### How It Works

1. **MCP Server Launch** — Claude Desktop starts `transcription-MCP/server.py` as a background process
2. **Skill Invocation** — User provides audio file path
3. **Transcription** — the MCP server sends the audio to the OpenAI or Azure OpenAI transcription API (`gpt-4o-transcribe` unless `OPENAI_TRANSCRIPTION_MODEL` or `AZURE_TRANSCRIPTION_MODEL` names another)
4. **Extraction** — Claude analyzes transcript and extracts 20 structured fields
5. **Validation** — Work phases validated against predefined lists
6. **Document Generation** — Word document created with 2-column table
7. **Presentation** — File saved and presented to user

### Dependencies

- **Python packages:** `mcp==1.30.0`, `gaik[transcriber]==0.12.0`, `python-dotenv==1.2.4`
- **External APIs:** OpenAI or Azure OpenAI transcription (`gpt-4o-transcribe` by default)

## Getting Help

- **GitHub Issues** — Report bugs or request features
- **SKILL.md** — View detailed field specifications and extraction rules
- **GAIK Toolkit** — Part of the GAIK (Generative AI Knowledge Management) toolkit

---

## License & Attribution

This skill is part of the GAIK toolkit. Built using:
- [MCP Python SDK](https://github.com/modelcontextprotocol/python-sdk) - MCP server framework (its `FastMCP` API, `mcp` 1.x)
- [GAIK](https://github.com/GAIK-project/gaik-toolkit) - Audio transcription library (`gaik` on PyPI)
- OpenAI or Azure OpenAI transcription API (`gpt-4o-transcribe` by default) - Speech-to-text
